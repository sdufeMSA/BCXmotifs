function Sortedmatrix = heatmap(matrix, biCluster, ClusterNoT)
% Method to display a heatmap after sorting the input
%
% Usage
% >> Sortedmatrix = heatmap(matrix, biCluster, ClusterNo)
%
% Inputs:
%   matrix                  - The data matrix where the bicluster is to
%                             be drawn.
%   biCluster (optional)    - A bicluster result set. If absent the data
%                             matrix is drawn as a heatmap, without any
%                             reordering.
%   ClusterNo               - Index of cluster to be plotted
%
% Outputs:
%   Sortedmatrix    - Sorted matrix
%
% Author: Jayesh Kumar Gupta, 2013.
%
% Contact: Jayesh Kumar Gupta http://home.iitk.ac.in/~jayeshkg
%          Indian Institute of Technology, Kanpur, India

if nargin < 1
    error('input :  No matrix as input');
end

if nargin < 2
    Sortedmatrix = matrix;
    figure;
    colormap(winter);
    imagesc(matrix);
    set(gca,'FontSize',14,'FontWeight','bold');
end

if nargin == 3
    if (biCluster.ClusterNo<ClusterNoT || ClusterNoT<0)
        error('Wrong Cluster Number: Cluster does not exist');
    end
    
    % Sorting Matrix
    % According to the Columns
    for i=1:ClusterNoT
    [a,soc] = sort(biCluster.NumxCol(i,:),'descend');
    matrix = matrix(:,soc)
    % According to the Rows
    [b,sor] = sort(biCluster.RowxNum(:,i),'descend');
    matrix = matrix(sor,:)
    end
    
    % Plotting
    figure;
    colormap(winter);
    imagesc(matrix);
    set(gca,'FontSize',14,'FontWeight','bold');
    hold on;
%     for ClusterNo=1:ClusterNoT
%     plot([length(biCluster.Clust(ClusterNo).cols)+0.5, ...
%         length(biCluster.Clust(ClusterNo).cols) + 0.5],...
%         [0.5, length(biCluster.Clust(ClusterNo).rows)+0.5], 'Color', 'r');
%     plot([0.5, length(biCluster.Clust(ClusterNo).cols)+0.5],...
%         [length(biCluster.Clust(ClusterNo).rows)+0.5, ...
%         length(biCluster.Clust(ClusterNo).rows)+0.5],'Color','r');
%     hold off;
%     end
end

if nargin > 3
    error('input: Wrong number of input');
end

